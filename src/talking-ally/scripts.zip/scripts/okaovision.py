#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# update: 2019/08/30
# created by: tatsumi
#

import termcolor
import rospy
from okao.msg import *
import numpy as np

import threading
import time


#------------------------------#
# OkaoVisionMonitor Class      #
#------------------------------#
class OkaoVisionMonitor:
	# 統合するカメラ情報
	chattername_list = []
	offset_list = []
	okao_list = []
	
	people = {}
	

	def __init__(self, chattername_list, offset_list):
		print("init!!")
		self.chattername_list = chattername_list
		self.offset_list = offset_list
		
		if len(chattername_list) != len(offset_list):
			# Notice...
			notice_init_error = '[OkaoVisionMonitor init] Error: Arguments size are wrong...'
			print(termcolor.colored(notice_init_error, 'red'))
			
		for chattername in self.chattername_list:
			self.okao_list += [OkaoVision(chattername)]
		
		# Notice...
		notice_init = '[OkaoVisionMonitor init]: Initialization Compete!\n'
		print(termcolor.colored(notice_init, 'green'))
		
		
	def start_updateLoop(self):
		update_loop = threading.Thread( target=self.updateLoop)
		update_loop.daemon = True
		update_loop.start()
		
		
	def updateLoop(self):
		while True:
			self.updateOkao()
			#self.printAll()
			time.sleep(0.05)
	
	
	# 検出しているすべての人を返す。
	def getAll(self):
		return self.people
		
				
	def updateOkao(self):
		self.people = {}
		for i in range(len(self.okao_list)):
			# edit people xy offset.
			raw_people = self.okao_list[i].getAll()
			for key in raw_people.keys():
				raw_people[key]["x"] += self.offset_list[i]["x"]
				raw_people[key]["y"] += self.offset_list[i]["y"]
				raw_people[key]["LR"] += self.offset_list[i]["LR"]
				raw_people[key]["UD"] += self.offset_list[i]["UD"]
				raw_people[key]["gazeLR"] += self.offset_list[i]["gazeLR"]
				raw_people[key]["gazeUD"] += self.offset_list[i]["gazeUD"]
				
			self.people.update(raw_people)
	
	
	def printAll(self):
		for key in self.people.keys():
			human = self.people[key]
			#showdata = np.array([human["x"], human["y"], human["LR"]])
			showdata = np.array([human["LR"], human["gazeLR"]])
			notice = str(showdata)+"\n"
			print(termcolor.colored(notice, 'yellow'))
		print(termcolor.colored("==========\n\n", 'yellow'))
		

#------------------------------#
# OkaoVision Class             #
#------------------------------#
class OkaoVision:
	people = {}
	

	def __init__(self, chattername):
		rospy.Subscriber(chattername, face_info, self.callback)
		
		# print LOG...
		notice_init = '[OkaoVisionMonitor init]: Initialization Compete!\n'
		notice_init += ' * \''+chattername+'\'\n'
		print(termcolor.colored(notice_init, 'green'))


	# 検出しているすべての人を返す。
	def getAll(self):
		return self.people


	def callback(self, msg):
		#notice = '[OkaoVision callback]: \n'
		#notice += ' * msg.face_count='+str(msg.face_count)+'\n'
		#print(termcolor.colored(notice, 'yellow'))

		# There is No people...
		if msg.face_count==0:
			self.people = {}
			pass
		# Hey, people!
		else:
			self.people = {}
			for idx in range(msg.face_count):
				self.people[msg.id[idx]] = self.getHuman(msg, idx)
			pass


	def getHuman(self, msg, idx):
		if idx>=0 & idx<msg.face_count & msg.face_count==0:
			return None
		else:
			human = {
				"id": msg.id[idx],\
				"x": msg.x[idx],\
				"y": msg.y[idx],\
				"size": msg.size[idx],\
				"LR": msg.LR[idx],\
				"UD": msg.UD[idx],\
				"gazeLR": msg.gazeLR[idx],\
				"gazeUD": msg.gazeUD[idx]}
			return human


if __name__ == '__main__':
	rospy.init_node('subscriber', anonymous=True)
	
	chatterlist = ['chatter_left', 'chatter_right']
	offsetlist = [{"x":-1000, "y":+0, "LR":+0, "gazeLR":0, "UD":+0, "gazeUD":0}, \
					{"x":-540, "y":+0, "LR":-0, "gazeLR":0, "UD":+0, "gazeUD":0}]
	okaomonitor = OkaoVisionMonitor(chatterlist, offsetlist)
	okaomonitor.start_updateLoop()
	
	rospy.spin()
	
