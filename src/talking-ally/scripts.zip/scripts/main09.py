#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# update: 2018/08/06 すべてのmoduleを統合 
# created by: tatsumi
#
# multiplayer and ally interaction...
#

import rospy

import okaovision
import head

import threading

from shared import Shared
import time
import numpy as np
import random

from shared import Shared

import pyaudio


#------------------------------#
# OkaoVisionManager Class      #
#------------------------------#
class OkaoVisionManager:
	hearer_list = []
	
	# ie. ["LR": [11: array(-50, ...), 12: array(-30, ...)]]
	attention_list = {"LR":{0:[]}, "UD":{0:[]}}
	
	# 
	attention_avr = {}
	okaomonitor = None
	

	def __init__(self, okaomonitor):
		self.okaomonitor = okaomonitor
		print("OkaoVisionManager is initialized!!")
	
	
	def start_updateLoop(self):
		update_loop = threading.Thread( target=self.updateLoop)
		update_loop.daemon = True
		update_loop.start()
		
		
	def updateLoop(self):
		while True:
			people = self.okaomonitor.getAll()
			
			attentionType = "LR"
			self.updateAttentionLog(people, attentionType)
			
			for key in people.keys():
				self.attention_avr[attentionType] = np.average(self.attention_list[attentionType][key])
				print(" >> ", self.attention_avr[attentionType])
				
			time.sleep(0.1)
			
	
	def updateAttentionLog(self, people, attentionType):
		for key in self.attention_list[attentionType].keys():
			if not key in people:
				del self.attention_list[attentionType][key]
		
		for key in people.keys():
			if not key in self.attention_list[attentionType]:
				self.attention_list[attentionType][key] = np.array([0] * 5)
			self.attention_list[attentionType][key] = \
			self.queue(self.attention_list[attentionType][key], people[key][attentionType])
			
			
	def queue(self, src, a):
		dst = np.roll(src, -1)
		dst[-1] = a
		return dst
		
		
#------------------------------#
# Interaction                  #
#------------------------------#
class Interaction:
	pass
	
	
	def __init__(self):
		pass
	
	
	def actionLoop(self):
		pass
		
		
#------------------------------#
# Main                         #
#------------------------------#
if __name__ == '__main__':
	rospy.init_node('subscriber', anonymous=True)
	
	chatterlist = ['chatter_left', 'chatter_right']
	offsetlist = [{"x":-1000, "y":+0, "LR":+0, "gazeLR":0, "UD":+0, "gazeUD":0}, \
					{"x":-540, "y":+0, "LR":-0, "gazeLR":0, "UD":+0, "gazeUD":0}]
	okaomonitor = okaovision.OkaoVisionMonitor(chatterlist, offsetlist)
	okaomonitor.start_updateLoop()
	
	okaomanager = OkaoVisionManager(okaomonitor)
	okaomanager.start_updateLoop()
	
	rospy.spin()
	
	
