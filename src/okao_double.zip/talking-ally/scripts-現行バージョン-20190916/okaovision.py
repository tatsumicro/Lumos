#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# update: 2019/08/30
# created by: tatsumi
#

import rospy
from okao.msg import *
import numpy as np


class OkaoVision:
	people = {}
	

	# ex. margin = {x:-100, y:30}
	def __init__(self, chattername):
		rospy.Subscriber(chattername, face_info, self.callback)
		print("OkaoVision Initialization Compete!")


	def getAll(self):
		return self.people


	def getXYList(self):
		return null


	def callback(self, msg):
		# There is No people...
		if msg.face_count==0:
			self.people = {}
			pass
		# Hey, people!
		else:
			self.people = {}
			for idx in range(msg.face_count):
				self.people[msg.id[idx]] = self.getHuman(msg, idx)
			pass


	def getHuman(self, msg, idx):
		if idx>=0 & idx<msg.face_count & msg.face_count==0:
			return None
		else:
			human = {
				"id": msg.id[idx],\
				"x": msg.x[idx],\
				"y": msg.y[idx],\
				"size": msg.size[idx],\
				"LR": msg.LR[idx],\
				"UD": msg.UD[idx],\
				"gazeLR": msg.gazeLR[idx],\
				"gazeUD": msg.gazeUD[idx]}
			return human

