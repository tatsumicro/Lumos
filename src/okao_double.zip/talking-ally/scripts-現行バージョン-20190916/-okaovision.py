#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# created by: tatsumi
#

import rospy
from okao.msg import *
import numpy as np


global PEOPLE
global BUF

global x
global y

def init():
    print("initialize!! 2020")
    global BUF
    BUF = 0
    global people
    people = {}
    rospy.Subscriber('chatter_okao', face_info, callback)
    print(sinWave(10))


def sinWave(n):
    x = np.linspace(0, 2*np.pi, n)
    return np.sin(x)


def callback(msg):
    if msg.face_count==0:
        global x
        global y
        lim_x = 400
        lim_y = 400
        if x > lim_x:
            x = x - 30
        if x < lim_x:
            x = x + 30
        if y > lim_y:
            y = y - 30
        if y < lim_y:
            y = y + 30
        
        human_new = {"id":10,\
             "x":x,\
             "y":y,\
             "size":80,\
             "LR":20,\
             "UD":20,\
             "gazeLR":0,\
             "gazeUD":0}
        people = {human_new}
        pass
        print("nothing...")
    else:
        global x
        global y
        x = msg.x[0]
        y = msg.y[0]
        print(x, y)


    	print("okao:: ", msg.face_count)
    	global BUF
    	global people
    	people = {}
    	for idx in range(msg.face_count):
            people[msg.id[idx]] = getHuman(msg, idx)
    
    	BUF = msg.UD[0]

    """
    if msg.face_count > 0:
        BUF= int(msg.UD[0])
    else:
        BUF = int(0)
    if msg.face_count > 0:
        BUF = msg.UD[0]
    else:
        pass
    """
    

def get():
    return int(BUF)


def getHuman(msg, idx):
    human = {"id":msg.id[idx],\
             "x":msg.x[idx],\
             "y":msg.y[idx],\
             "size":msg.size[idx],\
             "LR":msg.LR[idx],\
             "UD":msg.UD[idx],\
             "gazeLR":msg.gazeLR[idx],\
             "gazeUD":msg.gazeUD[idx]}
    return human

